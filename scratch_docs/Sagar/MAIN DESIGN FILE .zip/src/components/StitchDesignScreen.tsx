import React, { useState } from 'react';
import { 
  Sparkles, ExternalLink, Palette, Type, Layout, CheckCircle, 
  FileText, Code, Settings, Download, Cpu, HelpCircle, ArrowRight,
  Sliders, Copy, Check, Eye, Layers, Compass, Brain, Monitor
} from 'lucide-react';
import { ScreenId, StudentProfile } from '../types';

interface StitchDesignScreenProps {
  onNavigate: (target: ScreenId) => void;
  onLog: (action: string, status: 'SUCCESS' | 'INFO' | 'WARNING' | 'ERROR', details: string) => void;
  profile: StudentProfile | null;
}

export const StitchDesignScreen: React.FC<StitchDesignScreenProps> = ({
  onNavigate,
  onLog,
  profile
}) => {
  const [activeWorkspaceTab, setActiveWorkspaceTab] = useState<'blueprint' | 'colors' | 'typography' | 'components'>('blueprint');
  const [isExporting, setIsExporting] = useState(false);
  const [exportSuccess, setExportSuccess] = useState('');
  
  // Color sandbox states
  const [copiedColor, setCopiedColor] = useState<string | null>(null);
  const [glowIntensity, setGlowIntensity] = useState<number>(30); // percentages
  const [selectedAccent, setSelectedAccent] = useState<'cyan' | 'rose' | 'amber' | 'emerald' | 'violet'>('cyan');

  // Typography states
  const [customText, setCustomText] = useState('SYNAPE COGNITIVE CORE');
  const [fontSizeMultiplier, setFontSizeMultiplier] = useState<number>(1.2);

  // Wireframe / mock navigation interactive state
  const [selectedWireframeNode, setSelectedWireframeNode] = useState<string>('map');

  const stitchProjectUrl = "https://stitch.withgoogle.com/projects/10807521546649880478";
  
  const handleCopyColor = (hex: string, name: string) => {
    navigator.clipboard.writeText(hex);
    setCopiedColor(name);
    onLog('Copied Color Value', 'SUCCESS', `Hex ${hex} (${name}) copied to clipboard`);
    setTimeout(() => setCopiedColor(null), 2000);
  };

  const handleExportSystemBlueprint = () => {
    setIsExporting(true);
    onLog('Stitch Blueprint Export Initialized', 'INFO', `Compiling unified design system bundle with Stitch project metadata`);
    
    setTimeout(() => {
      setIsExporting(false);
      setExportSuccess('Stitch-System-Blueprint-Specification.txt compiled and downloaded.');
      onLog('Stitch Blueprint Export Complete', 'SUCCESS', `Stitch design specifications file generated`);
      
      const content = `========================================================================\n` +
                      `            SYNAPSE - GOOGLE STITCH SYSTEM DESIGN BLUEPRINT\n` +
                      `========================================================================\n` +
                      `Project ID: 10807521546649880478\n` +
                      `Design Platform: Google Stitch (Design with AI)\n` +
                      `Direct URL: ${stitchProjectUrl}\n\n` +
                      `VISUAL PROFILE SPECIFICATION:\n` +
                      `- Primary Palette: Deep Galactic & Slate (Dark Theme Only)\n` +
                      `- Canvas Background: Slate-950 (#020617)\n` +
                      `- Header / Navigation Bar: Slate-900 (#0f172a) with 90% blur backdrop\n` +
                      `- Cards & Section Containers: Slate-900/40 (#0f172a with 40% transparency)\n` +
                      `- Borders: High-contrast thin slate border (#1e293b) with active states at cyan-500/30\n` +
                      `- Primary Neon Accents: Cyan-400 (#22d3ee) & Cyan-500 (#06b6d4)\n` +
                      `- Subscores / Status Accents: Rose-400 (#f43f5e), Amber-400 (#fbbf24), Emerald-400 (#34d399), Violet-400 (#a78bfa)\n\n` +
                      `TYPOGRAPHIC SCHEMATIC:\n` +
                      `- Headings (Display & Hero): Space Grotesk / Inter Bold (Strict letter-spacing uppercase)\n` +
                      `- Interactive Elements & KPI Indicators: JetBrains Mono / Source Code Pro\n` +
                      `- Body Text & Labels: Inter / System Sans UI (High-contrast, generous line-height)\n\n` +
                      `COMPONENTS LIST:\n` +
                      `1. MapScreen: Interactive grid navigation of 4 main cognitive agents\n` +
                      `2. GqAssessment: Interactive adaptive logic assessment with real-time feedback\n` +
                      `3. AnalyticsScreen: CHC-Gq multidimensional intelligence profile & pilot cohort simulator\n` +
                      `4. AdminScreen: Interactive calibration overrides and bell curve distribution stats\n\n` +
                      `========================================================================\n` +
                      `Compiled on: ${new Date().toLocaleDateString()} ${new Date().toLocaleTimeString()}\n` +
                      `========================================================================\n`;
      const blob = new Blob([content], { type: 'text/plain' });
      const url = URL.createObjectURL(blob);
      const link = document.createElement('a');
      link.href = url;
      link.download = `Stitch-System-Blueprint-Specification.txt`;
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      setTimeout(() => setExportSuccess(''), 5000);
    }, 1200);
  };

  const colorsData = [
    { name: 'Canvas Background', hex: '#020617', tailwind: 'bg-slate-950', use: 'Main app canvas, full viewport backdrop' },
    { name: 'Surface Core', hex: '#0f172a', tailwind: 'bg-slate-900', use: 'Headers, panels, navigation modules' },
    { name: 'Section Container', hex: '#0f172a66', tailwind: 'bg-slate-900/40', use: 'Semi-transparent sub-panels, charts' },
    { name: 'Contrast Border', hex: '#1e293b', tailwind: 'border-slate-800', use: 'Default high-contrast structural dividing lines' },
    { name: 'Primary Accent', hex: '#22d3ee', tailwind: 'text-cyan-400', use: 'Interactive highlights, primary buttons, system state glows' },
    { name: 'Failure & Admin', hex: '#f43f5e', tailwind: 'text-rose-400', use: 'Error metrics, manual admin controls, warning states' },
    { name: 'Warning & Confidence', hex: '#fbbf24', tailwind: 'text-amber-400', use: 'Confidence sliders, warning levels, intermediate steps' },
    { name: 'Success & Metric', hex: '#34d399', tailwind: 'text-emerald-400', use: 'Correct answers, completed nodes, percentile increments' },
    { name: 'Subscore Special', hex: '#a78bfa', tailwind: 'text-violet-400', use: 'SolverBot pathways, subscore matrices, mathematical routes' }
  ];

  return (
    <div className="space-y-6 relative z-10 animate-fade-in text-slate-100">
      
      {/* Upper Brand Showcase Banner */}
      <div className="relative overflow-hidden bg-slate-900 border border-slate-800 rounded-2xl p-6 md:p-8 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div className="absolute -right-24 -bottom-24 w-96 h-96 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>
        <div className="absolute -left-24 -top-24 w-96 h-96 bg-pink-500/5 rounded-full blur-3xl pointer-events-none"></div>
        
        <div className="space-y-3 max-w-2xl">
          <div className="inline-flex items-center gap-1.5 px-2.5 py-1 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[10px] font-mono font-bold uppercase rounded-md tracking-wider">
            <Sparkles className="w-3.5 h-3.5 animate-pulse" />
            STITCH WITH GOOGLE DESIGN SYSTEM
          </div>
          <h2 className="text-2xl md:text-3xl font-black tracking-tight text-slate-100 font-space uppercase">
            STITCH DESIGN STUDIO
          </h2>
          <p className="text-xs text-slate-400 leading-relaxed font-sans">
            This workspace showcases the precise visual assets, UI components, typography, and color tokens designed in <strong className="text-cyan-400">Google Stitch (Beta)</strong> for project ID <code className="text-slate-200 bg-slate-950 px-1.5 py-0.5 rounded text-[11px] font-mono border border-slate-800 font-bold">10807521546649880478</code>.
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-3 w-full md:w-auto shrink-0">
          <a
            href={stitchProjectUrl}
            target="_blank"
            rel="noopener noreferrer"
            onClick={() => onLog('Stitch external design link clicked', 'INFO', `Opening Stitch project URL: ${stitchProjectUrl}`)}
            className="px-5 py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-mono font-bold text-xs uppercase rounded-lg flex items-center justify-center gap-2 transition-all duration-300 shadow-lg shadow-cyan-500/10 hover:shadow-cyan-500/20 hover:-translate-y-0.5"
          >
            <span>Launch Stitch Studio</span>
            <ExternalLink className="w-4 h-4" />
          </a>
          
          <button
            onClick={handleExportSystemBlueprint}
            disabled={isExporting}
            className="px-5 py-2.5 bg-slate-950 hover:bg-slate-900 border border-slate-800 hover:border-slate-700 text-slate-300 hover:text-white font-mono font-bold text-xs uppercase rounded-lg flex items-center justify-center gap-2 transition-all duration-300"
          >
            {isExporting ? (
              <>
                <svg className="animate-spin h-4 w-4 text-slate-400" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                <span>COMPILING...</span>
              </>
            ) : (
              <>
                <Download className="w-4 h-4" />
                <span>Export Design Specs</span>
              </>
            )}
          </button>
        </div>
      </div>

      {exportSuccess && (
        <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 p-4 rounded-xl text-xs font-mono text-center animate-pulse flex items-center justify-center gap-2">
          <CheckCircle className="w-4 h-4" />
          {exportSuccess}
        </div>
      )}

      {/* Main workspace layout */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
        
        {/* Left Sidebar navigation controls */}
        <div className="space-y-4">
          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 space-y-2">
            <span className="text-[10px] font-mono text-slate-500 block uppercase tracking-widest font-bold mb-2">Design Categories</span>
            
            <button
              onClick={() => setActiveWorkspaceTab('blueprint')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                activeWorkspaceTab === 'blueprint'
                  ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40 border border-transparent'
              }`}
            >
              <Layout className="w-4 h-4" />
              <span>Application Wireframe Map</span>
            </button>

            <button
              onClick={() => setActiveWorkspaceTab('colors')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                activeWorkspaceTab === 'colors'
                  ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40 border border-transparent'
              }`}
            >
              <Palette className="w-4 h-4" />
              <span>Color Swatch Sandbox</span>
            </button>

            <button
              onClick={() => setActiveWorkspaceTab('typography')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                activeWorkspaceTab === 'typography'
                  ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40 border border-transparent'
              }`}
            >
              <Type className="w-4 h-4" />
              <span>Typography Scales</span>
            </button>

            <button
              onClick={() => setActiveWorkspaceTab('components')}
              className={`w-full flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-xs font-mono font-semibold transition-all ${
                activeWorkspaceTab === 'components'
                  ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400'
                  : 'text-slate-400 hover:text-slate-200 hover:bg-slate-950/40 border border-transparent'
              }`}
            >
              <Code className="w-4 h-4" />
              <span>UI Component Spec</span>
            </button>
          </div>

          <div className="bg-slate-900 border border-slate-800 rounded-xl p-4 text-xs space-y-3 leading-normal font-sans">
            <span className="text-[10px] font-mono text-slate-500 block uppercase tracking-widest font-bold">Stitch Parameters</span>
            <div className="space-y-2 font-mono text-[11px] text-slate-400">
              <div className="flex justify-between"><span>Project Version</span><span className="text-slate-200">v1.0.8 (Beta)</span></div>
              <div className="flex justify-between"><span>Vite Setup</span><span className="text-cyan-400">Port 3000 Host</span></div>
              <div className="flex justify-between"><span>Contrast Index</span><span className="text-emerald-400">WCAG AAA compliant</span></div>
              <div className="flex justify-between"><span>Responsive Range</span><span className="text-pink-400">Fluid Max-7xl</span></div>
            </div>
            <div className="border-t border-slate-800/80 pt-2 text-[10px] text-slate-500">
              This layout guarantees a pixel-perfect dark visual theme with zero unrequested feature bloating.
            </div>
          </div>
        </div>

        {/* Right workspace interactive content container */}
        <div className="lg:col-span-3 bg-slate-900 border border-slate-800 rounded-2xl p-6 relative">
          
          {/* TAB 1: BLUEPRINT WIREFRAME */}
          {activeWorkspaceTab === 'blueprint' && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-200 font-mono">Application Wireframe Blueprint</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Interactive structural grid and viewport routing pathways mapped to the Stitch system model.</p>
                </div>
                <div className="flex items-center gap-1 bg-slate-950 border border-slate-850 px-2.5 py-1 rounded-md text-[10px] font-mono text-cyan-400">
                  <Monitor className="w-3 h-3" />
                  <span>INTERACTIVE MAP</span>
                </div>
              </div>

              {/* Wireframe Simulator */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-4 md:p-6 space-y-4">
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full bg-red-500/40"></div>
                    <div className="w-3 h-3 rounded-full bg-yellow-500/40"></div>
                    <div className="w-3 h-3 rounded-full bg-green-500/40"></div>
                    <span className="text-[10px] font-mono text-slate-500 ml-2">Synapse-Frame-Simulator.exe</span>
                  </div>
                  <div className="text-[10px] font-mono text-slate-400 bg-slate-900 px-2 py-0.5 rounded border border-slate-800">
                    Active View: <span className="text-cyan-400 font-bold">{selectedWireframeNode.toUpperCase()}</span>
                  </div>
                </div>

                {/* Wireframe Mock Layout Grid */}
                <div className="grid grid-cols-4 gap-2.5 text-center text-[10px] font-mono">
                  {/* Top Bar Wireframe */}
                  <div className="col-span-4 bg-slate-900/60 border border-slate-800 p-2.5 rounded-lg flex justify-between items-center">
                    <div className="flex items-center gap-1 text-slate-300 font-bold">
                      <Brain className="w-3.5 h-3.5 text-cyan-400" />
                      <span>SYNAPSE LOGO</span>
                    </div>
                    <div className="flex gap-2">
                      <span className="px-1.5 py-0.5 bg-slate-950 border border-slate-800 rounded text-slate-500">PROFILE STATS</span>
                      <span className="px-1.5 py-0.5 bg-rose-950/20 border border-rose-900/20 rounded text-rose-400">ADMIN BTN</span>
                    </div>
                  </div>

                  {/* Left Wireframe list */}
                  <div className="col-span-1 bg-slate-900/40 border border-slate-800 p-3 rounded-lg flex flex-col gap-2 text-left">
                    <span className="text-[9px] text-slate-500 font-bold block">NAVIGATION</span>
                    <button 
                      onClick={() => setSelectedWireframeNode('intake')}
                      className={`p-1.5 rounded text-[9px] text-left transition ${selectedWireframeNode === 'intake' ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400' : 'bg-slate-950 text-slate-400 border border-transparent'}`}
                    >
                      Intake Screen
                    </button>
                    <button 
                      onClick={() => setSelectedWireframeNode('map')}
                      className={`p-1.5 rounded text-[9px] text-left transition ${selectedWireframeNode === 'map' ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400' : 'bg-slate-950 text-slate-400 border border-transparent'}`}
                    >
                      Mission Map
                    </button>
                    <button 
                      onClick={() => setSelectedWireframeNode('gq-assessment')}
                      className={`p-1.5 rounded text-[9px] text-left transition ${selectedWireframeNode === 'gq-assessment' ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400' : 'bg-slate-950 text-slate-400 border border-transparent'}`}
                    >
                      Assessment Engine
                    </button>
                    <button 
                      onClick={() => setSelectedWireframeNode('cognitive-analytics')}
                      className={`p-1.5 rounded text-[9px] text-left transition ${selectedWireframeNode === 'cognitive-analytics' ? 'bg-cyan-500/10 border border-cyan-500/20 text-cyan-400' : 'bg-slate-950 text-slate-400 border border-transparent'}`}
                    >
                      Analytics Suite
                    </button>
                  </div>

                  {/* Main View Wireframe Window */}
                  <div className="col-span-3 bg-slate-900/30 border border-slate-800 p-4 rounded-lg flex flex-col justify-between min-h-[140px] text-left relative">
                    <div className="space-y-1.5 z-10">
                      <span className="text-[9px] text-cyan-500 font-bold block tracking-wider uppercase">STITCH SYSTEM WIREFRAME VIEW</span>
                      
                      {selectedWireframeNode === 'intake' && (
                        <div className="space-y-2 animate-fade-in text-[10px]">
                          <p className="text-slate-300 font-bold">1. Demographic Intake Port</p>
                          <p className="text-slate-500 text-[9px]">A double-panel card collecting Student Name, Grade Level Slider, Academy Origin, and Cognitive Focus. Includes high-contrast active inputs.</p>
                        </div>
                      )}

                      {selectedWireframeNode === 'map' && (
                        <div className="space-y-2 animate-fade-in text-[10px]">
                          <p className="text-slate-300 font-bold">2. Synapse Compass Map Grid</p>
                          <p className="text-slate-500 text-[9px]">A gorgeous 4-quadrant interactive grid featuring custom bot icons (PatternBot, CompareBot, SolverBot, VisionBot). Unlocked nodes feature glowing blue cybernetic borders.</p>
                        </div>
                      )}

                      {selectedWireframeNode === 'gq-assessment' && (
                        <div className="space-y-2 animate-fade-in text-[10px]">
                          <p className="text-slate-300 font-bold">3. Multi-Domain Adaptive Evaluation Core</p>
                          <p className="text-slate-500 text-[9px]">Continuous assessment with custom confidence feedback loops, live timers, and immediate logic gate calibration indicators.</p>
                        </div>
                      )}

                      {selectedWireframeNode === 'cognitive-analytics' && (
                        <div className="space-y-2 animate-fade-in text-[10px]">
                          <p className="text-slate-300 font-bold">4. Multidimensional Intelligence Diagnostic Suite</p>
                          <p className="text-slate-500 text-[9px]">Comprehensive analytics dashboards tracking CHC ability structures, bivariate latency scatterplots, and cohort simulation data streams.</p>
                        </div>
                      )}
                    </div>

                    <div className="flex justify-between items-center mt-3 z-10">
                      <span className="text-[9px] text-slate-500">Interactive Preview System</span>
                      <button 
                        onClick={() => onNavigate(selectedWireframeNode as ScreenId)}
                        className="px-2 py-1 bg-cyan-500/10 border border-cyan-500/30 text-cyan-400 rounded hover:bg-cyan-500 hover:text-slate-950 font-bold text-[9px] uppercase tracking-wide transition flex items-center gap-1"
                      >
                        <span>Activate Live View</span>
                        <ArrowRight className="w-2.5 h-2.5" />
                      </button>
                    </div>

                    {/* Faint Grid Background lines */}
                    <div className="absolute inset-0 grid grid-cols-6 grid-rows-6 opacity-10 pointer-events-none">
                      {Array.from({ length: 36 }).map((_, i) => (
                        <div key={i} className="border-b border-r border-slate-500"></div>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Grid Navigation Pathway Info */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-3 text-left">
                  <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                    <span className="text-[9px] font-mono text-cyan-400 block font-bold">NODE 01: INTAKE</span>
                    <span className="text-[10px] text-slate-400 leading-normal font-sans block">Demographic profiling & target cognitive alignment setting.</span>
                  </div>
                  <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                    <span className="text-[9px] font-mono text-cyan-400 block font-bold">NODE 02: MAP</span>
                    <span className="text-[10px] text-slate-400 leading-normal font-sans block">Grid map showing locked/unlocked cognitive test quadrants.</span>
                  </div>
                  <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                    <span className="text-[9px] font-mono text-cyan-400 block font-bold">NODE 03: ASSESSMENT</span>
                    <span className="text-[10px] text-slate-400 leading-normal font-sans block">Continuous item selection calibration with real-time feedback.</span>
                  </div>
                  <div className="p-3 bg-slate-900 border border-slate-850 rounded-lg space-y-1">
                    <span className="text-[9px] font-mono text-cyan-400 block font-bold">NODE 04: ANALYTICS</span>
                    <span className="text-[10px] text-slate-400 leading-normal font-sans block">Comprehensive multidimensional profiling with cohort indices.</span>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 2: COLOR SWATCH SANDBOX */}
          {activeWorkspaceTab === 'colors' && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-200 font-mono">Color Palette Swatches</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Primary dark-galactic slate canvas and colored telemetry indicators designed for deep focus.</p>
                </div>
                <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-850 px-2.5 py-1 rounded-md text-[10px] font-mono text-cyan-400">
                  <Palette className="w-3.5 h-3.5 animate-pulse" />
                  <span>STITCH SWATCHES</span>
                </div>
              </div>

              {/* Color Grid */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                {colorsData.map((color, i) => (
                  <div key={i} className="bg-slate-950 border border-slate-850 p-4 rounded-xl flex flex-col justify-between gap-3 group relative overflow-hidden">
                    <div className="flex gap-3 items-center">
                      <div className={`w-12 h-12 rounded-lg border border-slate-800 shadow-inner ${color.tailwind} shrink-0`}></div>
                      <div>
                        <span className="text-xs font-bold text-slate-200 block font-mono">{color.name}</span>
                        <span className="text-[10px] font-mono text-slate-400 block">{color.hex}</span>
                      </div>
                    </div>
                    
                    <p className="text-[10px] text-slate-500 font-sans leading-normal">
                      {color.use}
                    </p>

                    <button
                      onClick={() => handleCopyColor(color.hex, color.name)}
                      className="w-full mt-1.5 py-1.5 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-400 hover:text-slate-200 rounded text-[9px] font-mono flex items-center justify-center gap-1.5 transition uppercase font-bold"
                    >
                      {copiedColor === color.name ? (
                        <>
                          <Check className="w-3 h-3 text-emerald-400 animate-pulse" />
                          <span className="text-emerald-400 font-bold">COPIED!</span>
                        </>
                      ) : (
                        <>
                          <Copy className="w-3 h-3" />
                          <span>COPY HEX VALUE</span>
                        </>
                      )}
                    </button>
                  </div>
                ))}
              </div>

              {/* Color Interaction Sandbox */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4">
                <div className="flex items-center gap-2">
                  <Sliders className="w-4 h-4 text-cyan-400" />
                  <span className="text-xs font-bold text-slate-200 font-mono uppercase tracking-wide">Interactive Glow Calibration Sandbox</span>
                </div>
                
                <p className="text-xs text-slate-400 leading-normal">
                  Adjust the slider below to test the exact active border neon glow specified by the Stitch system. Live render a card using these values.
                </p>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
                  <div className="space-y-4">
                    <div className="space-y-1">
                      <div className="flex justify-between text-[11px] font-mono">
                        <span className="text-slate-400">Neon Glow Intensity</span>
                        <span className="text-cyan-400 font-bold">{glowIntensity}px</span>
                      </div>
                      <input 
                        type="range" 
                        min="5" 
                        max="80" 
                        value={glowIntensity} 
                        onChange={(e) => setGlowIntensity(Number(e.target.value))}
                        className="w-full accent-cyan-400 h-1.5 bg-slate-900 rounded-lg cursor-pointer"
                      />
                    </div>

                    <div className="space-y-2">
                      <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest font-bold block">Select Active Indicator color</span>
                      <div className="flex gap-2">
                        {['cyan', 'rose', 'amber', 'emerald', 'violet'].map((color) => (
                          <button
                            key={color}
                            onClick={() => setSelectedAccent(color as any)}
                            className={`px-3 py-1.5 rounded-md font-mono text-[10px] font-bold border transition capitalize ${
                              selectedAccent === color
                                ? 'bg-slate-900 text-slate-100 border-slate-700 shadow-md'
                                : 'bg-slate-950 text-slate-500 border-slate-900 hover:text-slate-300'
                            }`}
                          >
                            <span className={`inline-block w-2 h-2 rounded-full mr-1.5 ${
                              color === 'cyan' ? 'bg-cyan-400' :
                              color === 'rose' ? 'bg-rose-500' :
                              color === 'amber' ? 'bg-amber-400' :
                              color === 'emerald' ? 'bg-emerald-400' : 'bg-violet-400'
                            }`}></span>
                            {color}
                          </button>
                        ))}
                      </div>
                    </div>
                  </div>

                  {/* Rendered Live Preview Card */}
                  <div 
                    className="p-5 bg-slate-900 rounded-xl border transition-all duration-500 text-left space-y-3"
                    style={{
                      borderColor: 
                        selectedAccent === 'cyan' ? `rgba(34, 211, 238, 0.4)` :
                        selectedAccent === 'rose' ? `rgba(244, 63, 94, 0.4)` :
                        selectedAccent === 'amber' ? `rgba(251, 191, 36, 0.4)` :
                        selectedAccent === 'emerald' ? `rgba(52, 211, 153, 0.4)` : `rgba(167, 139, 250, 0.4)`,
                      boxShadow: 
                        selectedAccent === 'cyan' ? `0 0 ${glowIntensity}px rgba(34, 211, 238, 0.08)` :
                        selectedAccent === 'rose' ? `0 0 ${glowIntensity}px rgba(244, 63, 94, 0.08)` :
                        selectedAccent === 'amber' ? `0 0 ${glowIntensity}px rgba(251, 191, 36, 0.08)` :
                        selectedAccent === 'emerald' ? `0 0 ${glowIntensity}px rgba(52, 211, 153, 0.08)` : `0 0 ${glowIntensity}px rgba(167, 139, 250, 0.08)`,
                    }}
                  >
                    <div className="flex justify-between items-center">
                      <div className="inline-flex items-center gap-1.5 px-2 py-0.5 bg-slate-950 border border-slate-800 rounded text-[9px] font-mono text-slate-400 font-bold">
                        <Cpu className="w-3 h-3 text-cyan-400 animate-spin-slow" />
                        PREVIEW ENGINE
                      </div>
                      <span className="text-[10px] font-mono text-slate-500">SYNAPSE ACTIVE STATE</span>
                    </div>

                    <div className="space-y-1">
                      <h4 className="text-xs font-bold text-slate-200 font-mono uppercase tracking-wide">Cognitive Agent Calibrator</h4>
                      <p className="text-[11px] text-slate-400 font-sans leading-normal">
                        Active node measuring adaptive quantitative items in the continuous item-pool sandbox.
                      </p>
                    </div>

                    <div className="w-full bg-slate-950 h-1.5 rounded overflow-hidden">
                      <div className={`h-full w-[65%] rounded transition-all duration-500 ${
                        selectedAccent === 'cyan' ? 'bg-cyan-400' :
                        selectedAccent === 'rose' ? 'bg-rose-500' :
                        selectedAccent === 'amber' ? 'bg-amber-400' :
                        selectedAccent === 'emerald' ? 'bg-emerald-400' : 'bg-violet-400'
                      }`}></div>
                    </div>

                    <div className="flex justify-between text-[9px] font-mono text-slate-500">
                      <span>CALIBRATION PROGRESS</span>
                      <span className={
                        selectedAccent === 'cyan' ? 'text-cyan-400 font-bold' :
                        selectedAccent === 'rose' ? 'text-rose-400 font-bold' :
                        selectedAccent === 'amber' ? 'text-amber-400 font-bold' :
                        selectedAccent === 'emerald' ? 'text-emerald-400 font-bold' : 'text-violet-400 font-bold'
                      }>65.0% COMPLETED</span>
                    </div>
                  </div>
                </div>

              </div>
            </div>
          )}

          {/* TAB 3: TYPOGRAPHY SCALES */}
          {activeWorkspaceTab === 'typography' && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-200 font-mono">Typographic scale & Font pairings</h3>
                  <p className="text-xs text-slate-400 mt-0.5">Space Grotesk headings matched with JetBrains Mono scientific labels and Inter prose.</p>
                </div>
                <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-850 px-2.5 py-1 rounded-md text-[10px] font-mono text-cyan-400">
                  <Type className="w-3.5 h-3.5" />
                  <span>STITCH TYPO</span>
                </div>
              </div>

              {/* Interactive Font Tester */}
              <div className="bg-slate-950 border border-slate-800 rounded-xl p-5 space-y-4 text-left">
                <span className="text-[10px] font-mono text-slate-500 uppercase tracking-widest font-bold">Interactive Font specimen tester</span>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <label className="text-[10px] font-mono text-slate-400 block font-bold">Type text below to test styles live:</label>
                    <input 
                      type="text" 
                      value={customText} 
                      onChange={(e) => setCustomText(e.target.value.toUpperCase())}
                      className="w-full bg-slate-900 border border-slate-800 hover:border-slate-700 focus:border-cyan-500 focus:outline-none p-2.5 rounded-lg text-xs font-mono text-slate-200 transition"
                    />
                  </div>
                  <div className="space-y-1.5">
                    <div className="flex justify-between text-[10px] font-mono font-bold">
                      <span className="text-slate-400">Scale factor</span>
                      <span className="text-cyan-400">{fontSizeMultiplier.toFixed(1)}x</span>
                    </div>
                    <input 
                      type="range" 
                      min="0.8" 
                      max="2.0" 
                      step="0.1"
                      value={fontSizeMultiplier} 
                      onChange={(e) => setFontSizeMultiplier(Number(e.target.value))}
                      className="w-full accent-cyan-400 h-1.5 bg-slate-900 rounded-lg cursor-pointer"
                    />
                  </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-slate-900/80">
                  {/* Space Grotesk Preview */}
                  <div className="space-y-1">
                    <span className="text-[9px] font-mono text-slate-500 block font-bold uppercase tracking-wider">1. Space Grotesk / Inter Bold (Display Headings)</span>
                    <div 
                      className="font-space font-black tracking-widest text-slate-100 uppercase transition-all duration-300"
                      style={{ fontSize: `${24 * fontSizeMultiplier}px` }}
                    >
                      {customText || 'SYNAPSE COGNITIVE CORE'}
                    </div>
                    <p className="text-[10px] text-slate-400 font-sans leading-normal">
                      Font style: <code className="text-cyan-400">font-space font-black tracking-widest</code>. Used for primary branding elements, game card headings, and modal alerts to establish high visual presence.
                    </p>
                  </div>

                  {/* JetBrains Mono Preview */}
                  <div className="space-y-1 pt-2 border-t border-slate-900/40">
                    <span className="text-[9px] font-mono text-slate-500 block font-bold uppercase tracking-wider">2. JetBrains Mono (Scientific Telemetry Labels)</span>
                    <div 
                      className="font-mono-jb font-medium text-cyan-400 transition-all duration-300"
                      style={{ fontSize: `${11 * fontSizeMultiplier}px` }}
                    >
                      &gt;&gt; SYSTEM_CALIBRATION_VALUE: {customText ? customText.replace(/\s+/g, '_') : 'COGNITIVE_CORE_BOOT'} [SUCCESS]
                    </div>
                    <p className="text-[10px] text-slate-400 font-sans leading-normal">
                      Font style: <code className="text-cyan-400">font-mono-jb font-medium text-cyan-400</code>. Used inside event lists, telemetry parameters, database indicators, and technical logs.
                    </p>
                  </div>

                  {/* Inter Prose Preview */}
                  <div className="space-y-1 pt-2 border-t border-slate-900/40">
                    <span className="text-[9px] font-mono text-slate-500 block font-bold uppercase tracking-wider">3. Inter / Sans UI (Readability & Form Prose)</span>
                    <div 
                      className="font-sans text-slate-300 leading-relaxed transition-all duration-300"
                      style={{ fontSize: `${11 * fontSizeMultiplier}px` }}
                    >
                      Testing custom string: "{customText.toLowerCase()}" represents the adaptive item pool that structures quantitative evaluation matrices.
                    </div>
                    <p className="text-[10px] text-slate-400 font-sans leading-normal">
                      Font style: <code className="text-cyan-400">font-sans text-slate-300 leading-relaxed</code>. Perfect for long blocks of assessment text, quiz descriptions, and student instructional blocks.
                    </p>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* TAB 4: UI COMPONENT SPECIFICATION */}
          {activeWorkspaceTab === 'components' && (
            <div className="space-y-6 animate-fade-in">
              <div className="border-b border-slate-800 pb-3 flex justify-between items-center">
                <div>
                  <h3 className="text-base font-bold text-slate-200 font-mono">UI Component Specification</h3>
                  <p className="text-xs text-slate-400 mt-0.5">High-contrast, state-driven widgets optimized for cognitive logic game loops.</p>
                </div>
                <div className="flex items-center gap-1.5 bg-slate-950 border border-slate-850 px-2.5 py-1 rounded-md text-[10px] font-mono text-cyan-400">
                  <Code className="w-3.5 h-3.5 animate-pulse" />
                  <span>STITCH COMPONENTS</span>
                </div>
              </div>

              {/* Component Gallery Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                
                {/* Component 1 */}
                <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl space-y-3 text-left">
                  <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                    <span className="text-[10px] font-mono font-bold text-cyan-400">1. Adaptive Button Module</span>
                    <span className="text-[9px] font-mono text-slate-500">Interactive state</span>
                  </div>
                  
                  <div className="space-y-2">
                    <button className="w-full py-2 px-4 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-mono font-bold text-xs uppercase rounded-lg transition-all shadow-md shadow-cyan-500/5 hover:-translate-y-0.5">
                      Primary Cyan Button
                    </button>
                    <button className="w-full py-2 px-4 bg-slate-900 hover:bg-slate-850 border border-slate-800 hover:border-slate-700 text-slate-300 rounded-lg text-xs font-mono uppercase tracking-wide transition">
                      Secondary Slate Button
                    </button>
                  </div>
                  
                  <p className="text-[10px] text-slate-500 leading-normal font-sans">
                    Utilizes custom active letter-spacing, immediate hover state changes, and subtle vertical lifting micro-animations.
                  </p>
                </div>

                {/* Component 2 */}
                <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl space-y-3 text-left">
                  <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                    <span className="text-[10px] font-mono font-bold text-cyan-400">2. Metric Pill badges</span>
                    <span className="text-[9px] font-mono text-slate-500">State Indicators</span>
                  </div>
                  
                  <div className="flex flex-wrap gap-2">
                    <span className="px-2 py-0.5 bg-cyan-500/10 border border-cyan-500/20 text-cyan-400 text-[9px] font-mono font-bold uppercase rounded-md tracking-wider">
                      STATUS ACTIVE
                    </span>
                    <span className="px-2 py-0.5 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[9px] font-mono font-bold uppercase rounded-md tracking-wider">
                      CALIBRATION REJECT
                    </span>
                    <span className="px-2 py-0.5 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[9px] font-mono font-bold uppercase rounded-md tracking-wider">
                      SUCCESS +450 XP
                    </span>
                    <span className="px-2 py-0.5 bg-slate-900 border border-slate-800 text-slate-400 text-[9px] font-mono uppercase rounded-md tracking-wider">
                      LOCKED STU104
                    </span>
                  </div>
                  
                  <p className="text-[10px] text-slate-500 leading-normal font-sans">
                    Uses small uppercase font trackers with custom opacity backgrounds corresponding directly to their semantic context.
                  </p>
                </div>

                {/* Component 3 */}
                <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl space-y-3 text-left">
                  <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                    <span className="text-[10px] font-mono font-bold text-cyan-400">3. High-Contrast Data Input Slider</span>
                    <span className="text-[9px] font-mono text-slate-500">Interactive Intake</span>
                  </div>
                  
                  <div className="space-y-2 bg-slate-900 p-2.5 rounded-lg border border-slate-850">
                    <div className="flex justify-between text-[10px] font-mono">
                      <span className="text-slate-400">Age: 17 years</span>
                      <span className="text-cyan-400">Calibration Factor: 1.05</span>
                    </div>
                    <div className="relative">
                      <div className="w-full bg-slate-950 h-1.5 rounded-full"></div>
                      <div className="absolute top-0 left-0 bg-gradient-to-r from-cyan-500 to-cyan-400 h-1.5 w-[60%] rounded-full"></div>
                      <div className="absolute top-0 left-[60%] -translate-y-[4px] -translate-x-[6px] w-3.5 h-3.5 bg-slate-100 border border-cyan-400 rounded-full shadow cursor-pointer"></div>
                    </div>
                  </div>
                  
                  <p className="text-[10px] text-slate-500 leading-normal font-sans">
                    Implements custom gradient indicators and rounded touch points to prevent click fatigue on high-frequency sliders.
                  </p>
                </div>

                {/* Component 4 */}
                <div className="bg-slate-950 border border-slate-850 p-4 rounded-xl space-y-3 text-left">
                  <div className="flex justify-between items-center border-b border-slate-900 pb-2">
                    <span className="text-[10px] font-mono font-bold text-cyan-400">4. Diagnostic Wave Amplitude</span>
                    <span className="text-[9px] font-mono text-slate-500">Active Canvas render</span>
                  </div>
                  
                  <div className="h-14 bg-slate-900 rounded-lg border border-slate-850 overflow-hidden flex items-center justify-center relative">
                    <svg className="w-full h-10 stroke-cyan-400 stroke-2 fill-none overflow-visible">
                      <path d="M0 20 Q20 4, 40 20 T80 20 T120 20 T160 20 T200 20 T240 20 T280 20 T320 20 T360 20 T400 20" />
                    </svg>
                    <div className="absolute inset-0 bg-gradient-to-t from-cyan-500/5 to-transparent pointer-events-none"></div>
                  </div>
                  
                  <p className="text-[10px] text-slate-500 leading-normal font-sans">
                    Bivariate sine waves showing dynamic feedback states on a fluid grid context.
                  </p>
                </div>

              </div>
            </div>
          )}

        </div>
      </div>

    </div>
  );
};
